<?php

$profileConnect("10.200.20.198","root","password","profile");
if (!mysqli_ping($profileConnect)) 
			{
		    		echo 'Lost connection, exiting after query #1';
		    		exit;
			}



?>
